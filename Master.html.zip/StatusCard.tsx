import type React from "react"
import { motion } from "framer-motion"

interface StatusCardProps {
  icon: React.ReactNode
  title: string
  value: string
}

export function StatusCard({ icon, title, value }: StatusCardProps) {
  return (
    <motion.div
      className="flex items-center p-4 bg-blue-50 rounded-lg"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <div className="flex-shrink-0 text-blue-500">{icon}</div>
      <div className="ml-4">
        <p className="text-sm font-medium text-gray-500">{title}</p>
        <p className="text-lg font-semibold text-gray-900">{value}</p>
      </div>
    </motion.div>
  )
}

