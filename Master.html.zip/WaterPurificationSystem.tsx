import React, { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  DropletsIcon as WaterDrop,
  FastForwardIcon as Speed,
  CloudOffIcon as Opacity,
  GlassWaterIcon as WaterFlow,
  Settings,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { StatusCard } from "./StatusCard"
import { useWaterPurification } from "./useWaterPurification"
import { SplashScreen } from "./SplashScreen"
import { Logo } from "./Logo"

export default function WaterPurificationSystem() {
  const [showSplash, setShowSplash] = useState(true)
  const {
    tdsValue,
    roFlowRate,
    rawFlowRate,
    totalWaterDispensed,
    rawWaterConsumed,
    isRORunning,
    maxWaterDispensed,
    setMaxWaterDispensed,
    handleReset,
  } = useWaterPurification(7500)

  return (
    <>
      <AnimatePresence>{showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}</AnimatePresence>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 3 }}
        className="min-h-screen bg-gradient-to-br from-blue-100 to-blue-200 p-6"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 3.2 }}
          className="max-w-md mx-auto bg-white rounded-xl shadow-lg overflow-hidden"
        >
          <div className="p-8">
            <motion.div
              className="flex items-center justify-center mb-6"
              initial={{ scale: 0.5 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 20, delay: 3.4 }}
            >
              <Logo className="w-16 h-16 mr-4" />
              <h1 className="text-3xl font-bold text-blue-600">PureFlow</h1>
            </motion.div>

            <div className="space-y-6">
              <StatusCard icon={<Opacity />} title="TDS Value" value={`${tdsValue.toFixed(2)} ppm`} />
              <StatusCard icon={<Speed />} title="RO Flow Rate" value={`${roFlowRate.toFixed(2)} L/min`} />
              <StatusCard icon={<Speed />} title="Raw Flow Rate" value={`${rawFlowRate.toFixed(2)} L/min`} />
              <StatusCard
                icon={<WaterDrop />}
                title="Total Water Dispensed"
                value={`${totalWaterDispensed.toFixed(2)} L`}
              />
              <StatusCard icon={<WaterFlow />} title="Raw Water Consumed" value={`${rawWaterConsumed.toFixed(2)} L`} />
            </div>

            <div className="mt-8">
              <label className="text-sm font-medium text-gray-700">Water Dispensed Progress</label>
              <Progress value={(totalWaterDispensed / maxWaterDispensed) * 100} className="mt-2" />
            </div>

            <div className="mt-8 flex justify-between items-center">
              <span className={`font-semibold ${isRORunning ? "text-green-500" : "text-red-500"}`}>
                RO System: {isRORunning ? "Running" : "Stopped"}
              </span>
              <Button onClick={handleReset} disabled={isRORunning}>
                Reset System
              </Button>
            </div>

            <div className="mt-8 flex items-center space-x-2">
              <Settings className="text-gray-400" />
              <span className="text-sm font-medium text-gray-700">Max Water:</span>
              <Input
                type="number"
                value={maxWaterDispensed}
                onChange={(e) => setMaxWaterDispensed(Number(e.target.value))}
                className="w-24"
              />
              <span className="text-sm text-gray-500">L</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </>
  )
}

