import WaterPurificationSystem from "./WaterPurificationSystem"

export default function Home() {
  return (
    <main>
      <WaterPurificationSystem />
    </main>
  )
}

