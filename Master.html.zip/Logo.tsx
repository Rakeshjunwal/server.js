import React from "react"

interface LogoProps {
  className?: string
}

export function Logo({ className = "w-24 h-24" }: LogoProps) {
  return (
    <svg className={className} viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="water-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#60A5FA" />
          <stop offset="100%" stopColor="#3B82F6" />
        </linearGradient>
        <filter id="shadow">
          <feDropShadow dx="0" dy="1" stdDeviation="2" floodOpacity="0.3" />
        </filter>
      </defs>
      <circle cx="50" cy="50" r="48" fill="white" filter="url(#shadow)" />
      <path d="M50 20 C 30 40, 30 70, 50 80 C 70 70, 70 40, 50 20" fill="url(#water-gradient)">
        <animateTransform
          attributeName="transform"
          type="translate"
          values="0 0; 0 2; 0 0"
          dur="3s"
          repeatCount="indefinite"
        />
      </path>
      <path d="M50 20 C 40 35, 40 55, 50 65 C 60 55, 60 35, 50 20" fill="white" opacity="0.3">
        <animateTransform
          attributeName="transform"
          type="translate"
          values="0 0; 0 2; 0 0"
          dur="3s"
          repeatCount="indefinite"
        />
      </path>
      <circle cx="65" cy="35" r="4" fill="white" opacity="0.6">
        <animate attributeName="cy" values="35; 33; 35" dur="3s" repeatCount="indefinite" />
      </circle>
    </svg>
  )
}

