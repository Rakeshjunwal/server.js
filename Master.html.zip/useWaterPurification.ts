import { useState, useEffect } from "react"

export function useWaterPurification(initialMaxWater: number) {
  const [tdsValue, setTdsValue] = useState(0)
  const [roFlowRate, setRoFlowRate] = useState(0)
  const [rawFlowRate, setRawFlowRate] = useState(0)
  const [totalWaterDispensed, setTotalWaterDispensed] = useState(0)
  const [rawWaterConsumed, setRawWaterConsumed] = useState(0)
  const [isRORunning, setIsRORunning] = useState(true)
  const [maxWaterDispensed, setMaxWaterDispensed] = useState(initialMaxWater)

  useEffect(() => {
    const timer = setInterval(() => {
      setTdsValue(Math.random() * 1000)
      setRoFlowRate(Math.random() * 10)
      setRawFlowRate(Math.random() * 15)
      setTotalWaterDispensed((prev) => {
        const newValue = prev + roFlowRate / 60
        if (newValue >= maxWaterDispensed) {
          setIsRORunning(false)
        }
        return newValue
      })
      setRawWaterConsumed((prev) => prev + rawFlowRate / 60)
    }, 1000)

    return () => clearInterval(timer)
  }, [roFlowRate, rawFlowRate, maxWaterDispensed])

  const handleReset = () => {
    setTotalWaterDispensed(0)
    setRawWaterConsumed(0)
    setIsRORunning(true)
  }

  return {
    tdsValue,
    roFlowRate,
    rawFlowRate,
    totalWaterDispensed,
    rawWaterConsumed,
    isRORunning,
    maxWaterDispensed,
    setMaxWaterDispensed,
    handleReset,
  }
}

